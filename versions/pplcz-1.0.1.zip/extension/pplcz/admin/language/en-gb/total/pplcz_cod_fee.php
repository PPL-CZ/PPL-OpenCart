<?php

// Heading
$_['heading_title'] = 'PPL.CZ (práce s dobírkou)';
