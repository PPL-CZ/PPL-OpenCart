<?php
namespace Opencart\Admin\Model\Extension\Pplcz;


require_once  __DIR__ . '/../../autoload.php';

/**
 * @property-read $model_setting_setting
 */
class Address extends \PPLCZ\Repository\Address
{

}