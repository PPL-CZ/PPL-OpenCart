<?php
namespace Opencart\Admin\Model\Extension\Pplcz;

require_once  __DIR__ . '/../../autoload.php';

use Opencart\System\Engine\Model;

class Log extends \PPLCZ\Repository\Log
{

}