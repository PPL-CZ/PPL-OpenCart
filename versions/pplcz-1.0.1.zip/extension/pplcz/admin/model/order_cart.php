<?php

namespace Opencart\Admin\Model\Extension\Pplcz;

use PPLCZ\Data\AddressData;
use PPLCZ\Data\OrderCartData;
use PPLCZ\Model\Model\CartModel;
use PPLCZ\Model\Model\ParcelDataModel;

require_once  __DIR__ . '/../../autoload.php';

class OrderCart extends \PPLCZ\Repository\OrderCart
{


}