<?php
namespace Opencart\Admin\Model\Extension\Pplcz;

use PPLCZ\Repository\Data;

require_once  __DIR__ . '/../../autoload.php';

class Package extends Data
{

}
