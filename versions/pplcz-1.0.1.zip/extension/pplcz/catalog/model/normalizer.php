<?php
namespace Opencart\Catalog\Model\Extension\Pplcz;

require_once  __DIR__ . '/../../autoload.php';

class Normalizer extends \PPLCZ\Repository\Normalizer
{

}