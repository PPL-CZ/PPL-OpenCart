<?php
namespace Opencart\Catalog\Model\Extension\Pplcz;

require_once  __DIR__ . '/../../autoload.php';

class Setting extends \PPLCZ\Repository\Setting
{

}
