<?php
namespace PPLCZ\Data;

class CartProxy
{
    public $storeId;

    /**
     * @var OrderCartData
     */
    public $orderCart;

    /**
     * @var string
     */
    public $shipmentType;
}