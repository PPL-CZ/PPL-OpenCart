<?php
namespace PPLCZ\Data;

class OrderProxy {

    public $id;

}